package reg;

public class Main {
    public static void main(String[] args)
    { 
    	RegistrationForm obj=new RegistrationForm();
    
    }
}